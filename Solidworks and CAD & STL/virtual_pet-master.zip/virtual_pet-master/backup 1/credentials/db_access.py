import os

user = os.environ["MLAB_USER"]
password = os.environ["MLAB_PASS"]
